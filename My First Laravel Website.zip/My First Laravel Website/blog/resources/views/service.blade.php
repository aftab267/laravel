@extends('layout.app')
@section('title','service')
@section('content')
<div class="container-fluid bg-dark mt-5"><br><br>
  <div class="row">
      <div class="col-md-12 text-center text-white mb-5">
<h4>My Services</h4>
  </div>
  </div>
</div>
<div class="container mt-5"><br><br>
    <div class="row">
        <div class="col-md-4">
            <div class="card" style="width: 100%;">
            <img class="card-img-top" src="{{asset('images/portfolio_image.jpg')}}" alt="Card image cap">
             <div class="card-body">
             <h5 class="card-title">Card title</h5>
             <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
             <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
            </div>
  </div>
  <div class="col-md-4">
    <div class="card" style="width: 100%;">
    <img class="card-img-top" src="{{asset('images/portfolio_image.jpg')}}" alt="Card image cap">
     <div class="card-body">
     <h5 class="card-title">Card title</h5>
     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    </div>
</div>
<div class="col-md-4">
    <div class="card" style="width: 100%;">
    <img class="card-img-top" src="{{asset('images/portfolio_image.jpg')}}" alt="Card image cap">
     <div class="card-body">
     <h5 class="card-title">Card title</h5>
     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    </div>
</div>
    </div>
</div>
<div class="container mb-5 mt-5">
    <div class="row">
        <div class="col-md-6">
               <form>
                <div class="form-group">
                  <label for="exampleInputEmail1">Your Name</label>
                  <input type="Text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Your Name">
                  
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Mobile No</label>
                  <input type="Text" class="form-control" id="exampleInputPassword1" placeholder="Mobile No">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Email</label>
                    <input type="email" class="form-control" id="exampleInputPassword1" placeholder="Email">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Your Message</label>
                    <input type="email" class="form-control" id="exampleInputPassword1" placeholder="Your Message">
                  </div>
                
                <button type="submit" class="btn btn-primary btn-block">Sent Now</button>
                </form>

        </div>  
        <div class="col-md-6">
            <h5>Address</h5>
            <p> 26/7, Ground Floor,Block-c,Tagmahal Road, Mohammadpur, Dhaka-1207</p>
            <p>+8801711241125</P>
                <p>aftab267@gmail.com</P>
        </div> 
    </div>    
</div>
@endsection