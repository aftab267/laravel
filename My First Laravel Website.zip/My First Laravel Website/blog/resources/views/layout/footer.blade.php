<div class="container mb-5 bg-light ">
    <div class="row">
        <div class="col-md-3">
            <h5>Follow Me</h5>
            <a href="#">Twitter</a><br>
            <a href="#">Instagram</a><br>
            <a href="">Linkedin</a><br>
        </div>
        <div class="col-md-3">
            <h5>My Address</h5>
            <a href="#">Link 1</a><br>
            <a href="#">Link 2</a><br>
            <a href="">Link 3</a><br>
            <a href="">Link 4</a><br>
        </div>
        <div class="col-md-3">
            <h5>Information</h5>
            <a href="#">Link 1</a><br>
            <a href="#">Link 2</a><br>
            <a href="">Link 3</a><br>
            <a href="">Link 4</a><br>
        </div>
        <div class="col-md-3">
            <h5>Legal</h5>
            <a href="#">Link 1</a><br>
            <a href="#">Link 2</a><br>
            <a href="">Link 3</a><br>
            <a href="">Link 4</a><br>
        </div>
</div>
</div>
<div class="container-fluid bg-dark">

<div class="row p-4">
    <div class="col-md-12 text-center text-white">
        <h5>Copyright-All right reverved by Kazi Aftabur Rahman-2021</h5>
    </div>
    
</div>
</div>
