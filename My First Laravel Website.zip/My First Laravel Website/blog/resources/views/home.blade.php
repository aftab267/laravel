@extends('layout.app')
@section('title','home')
@section('content')

<div class="container-fluid parallax mb-5"><br><br>
    <div class="row d-flex justify-content-center ">
        <div class="col-md-4 align-center text-center topdiv ">
  <h1 class=" text-white ">Software Engineer</h1>
  <h3 class=" text-white ">Mobile & Web</h3>
  <button type="submit" class="btn btn-primary">Sent Now</button>
        </div>
    

</div>
</div>
<div class="container mt-5">
<div class="row">
<div class="col-md-12">
          <div class="card" style="width: 300px;">
          <img class="card-img-top" src="{{asset('images/aftab.jpg')}}" alt="Card image cap">
           <div class="card-body">
           <h5 class="card-title"><b>Kazi Aftabur Rahman</b></h5>
           <h6 class="card-title"><b>Web Developer & Graphic Designer</b></h6>
           <p class="card-text">I am a professional Web developer.I can work in graphic design also.</p>
           <h6> My Phone: +8801711241125</h6>
           <h6> My email: aftab267@gmail.com</h6>
           <a href="{{url('portfolio')}}" class="btn btn-primary">My portfolio</a>
          </div>
          </div>
</div>

</div>
</div>

<div class="container text-center mt-5 mb-5">
    <H2>My Services</h2><br><br>
    <div class="row">
        <div class="col-md-4">
            <div class="card" style="width: 100%;">
            <img class="card-img-top" src="{{asset('images/portfolio_image.jpg')}}" alt="Card image cap">
             <div class="card-body">
             <h5 class="card-title">Card title</h5>
             <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
             <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
            </div>
  </div>
  <div class="col-md-4">
    <div class="card" style="width: 100%;">
    <img class="card-img-top" src="{{asset('images/portfolio_image.jpg')}}" alt="Card image cap">
     <div class="card-body">
     <h5 class="card-title">Card title</h5>
     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    </div>
</div>
<div class="col-md-4">
    <div class="card" style="width: 100%;">
    <img class="card-img-top" src="{{asset('images/portfolio_image.jpg')}}" alt="Card image cap">
     <div class="card-body">
     <h5 class="card-title">Card title</h5>
     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    </div>
</div>
</div>
</div>
<div class="container text-center mt-5 mb-5">
    <H2>Recent Projects</h2><br><br>
    <div class="row">
        <div class="col-md-4">
            <div class="card" style="width: 100%;">
            <img class="card-img-top" src="{{asset('images/portfolio_image.jpg')}}" alt="Card image cap">
             <div class="card-body">
             <h5 class="card-title">Recent project</h5>
             <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
             <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
            </div>
  </div>
  <div class="col-md-4">
    <div class="card" style="width: 100%;">
    <img class="card-img-top" src="{{asset('images/portfolio_image.jpg')}}" alt="Card image cap">
     <div class="card-body">
     <h5 class="card-title">Recent project</h5>
     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    </div>
</div>
<div class="col-md-4">
    <div class="card" style="width: 100%;">
    <img class="card-img-top" src="{{asset('images/portfolio_image.jpg')}}" alt="Card image cap">
     <div class="card-body">
     <h5 class="card-title">Recent project</h5>
     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    </div>
</div>
</div>
</div>













@endsection
