<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\sitecontroller;

Route::get('/',[sitecontroller::class,'showhome']);
Route::get('/about',[sitecontroller::class,'showabout']);
Route::get('/service',[sitecontroller::class,'showservice']);
Route::get('/portfolio',[sitecontroller::class,'showportfolio']);

