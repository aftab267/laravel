<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class sitecontroller extends Controller
{
    function showhome(){
    return view('home');
    }
    function showabout(){
      return view('about'); 
    }
    function showservice(){
        return view('service');
    }
    function showportfolio(){
        return view('portfolio');
    }
}
