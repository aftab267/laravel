
<?php $__env->startSection('title','portfolio'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-dark mt-5"><br><br>
    <div class="row">
        <div class="col-md-12 text-center text-white mb-5">
<h4>My portfolio</h4>
    </div>
    </div>
</div>

<div class="container mt-5">
<div class="row">
<div class="col-md-3">
          <div class="card" style="width: 100%;">
          <img class="card-img-top" src="<?php echo e(asset('images/portfolio_image.jpg')); ?>" alt="Card image cap">
           <div class="card-body">
           <h5 class="card-title">Card title</h5>
           <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
           <a href="#" class="btn btn-primary">Go somewhere</a>
          </div>
          </div>
</div>
<div class="col-md-3">
    <div class="card" style="width: 100%;">
    <img class="card-img-top" src="<?php echo e(asset('images/portfolio_image.jpg')); ?>" alt="Card image cap">
     <div class="card-body">
     <h5 class="card-title">Card title</h5>
     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    </div>
</div>
<div class="col-md-3">
    <div class="card" style="width: 100%;">
    <img class="card-img-top" src="<?php echo e(asset('images/portfolio_image.jpg')); ?>" alt="Card image cap">
     <div class="card-body">
     <h5 class="card-title">Card title</h5>
     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    </div>
</div>
<div class="col-md-3">
    <div class="card" style="width: 100%;">
    <img class="card-img-top" src="<?php echo e(asset('images/portfolio_image.jpg')); ?>" alt="Card image cap">
     <div class="card-body">
     <h5 class="card-title">Card title</h5>
     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    </div>
</div>
<div class="col-md-3">
    <div class="card" style="width: 100%;">
    <img class="card-img-top" src="<?php echo e(asset('images/portfolio_image.jpg')); ?>" alt="Card image cap">
     <div class="card-body">
     <h5 class="card-title">Card title</h5>
     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    </div>
</div>
<div class="col-md-3">
    <div class="card" style="width: 100%;">
    <img class="card-img-top" src="<?php echo e(asset('images/portfolio_image.jpg')); ?>" alt="Card image cap">
     <div class="card-body">
     <h5 class="card-title">Card title</h5>
     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    </div>
</div>
<div class="col-md-3">
    <div class="card" style="width: 100%;">
    <img class="card-img-top" src="<?php echo e(asset('images/portfolio_image.jpg')); ?>" alt="Card image cap">
     <div class="card-body">
     <h5 class="card-title">Card title</h5>
     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    </div>
</div>
<div class="col-md-3">
    <div class="card" style="width: 100%;">
    <img class="card-img-top" src="<?php echo e(asset('images/portfolio_image.jpg')); ?>" alt="Card image cap">
     <div class="card-body">
     <h5 class="card-title">Card title</h5>
     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    </div>
</div>

</div>
</div>
<div class="container mb-5 mt-5">
    <h2 class=" text-center mb-5">Contact With Me</h2>
    <div class="row">
        <div class="col-md-6">
               <form>
                <div class="form-group">
                  <label for="exampleInputEmail1">Your Name</label>
                  <input type="Text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Your Name">
                  
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Mobile No</label>
                  <input type="Text" class="form-control" id="exampleInputPassword1" placeholder="Mobile No">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Email</label>
                    <input type="email" class="form-control" id="exampleInputPassword1" placeholder="Email">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Your Message</label>
                    <input type="email" class="form-control" id="exampleInputPassword1" placeholder="Your Message">
                  </div>
                
                <button type="submit" class="btn btn-primary btn-block">Sent Now</button>
                </form>

        </div>  
        <div class="col-md-6">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.5588463165745!2d90.35863411536285!3d23.76310609420684!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c0a754efe6d1%3A0x51a4db3c9946ad1b!2s26%2C%207%20Tajmahal%20Rd%2C%20Dhaka!5e0!3m2!1sen!2sbd!4v1624720088392!5m2!1sen!2sbd" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div> 
    </div>    
</div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mypc\Desktop\My First Laravel Website\blog\resources\views/portfolio.blade.php ENDPATH**/ ?>