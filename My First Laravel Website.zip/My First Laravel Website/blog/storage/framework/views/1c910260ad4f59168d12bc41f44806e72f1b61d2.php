<html>
<head>
 <title><?php echo $__env->yieldContent('title'); ?></title>
 <link  rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
 <link  rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
 <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet"> 

</head>


<body>
<?php echo $__env->make('layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->yieldContent('content'); ?>



    
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('js/jquery-3.2.1.slim.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>    
</boby>
</html><?php /**PATH C:\Users\mypc\Desktop\My First Laravel Website\blog\resources\views/layout/app.blade.php ENDPATH**/ ?>